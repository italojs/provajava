package br.com.fiap.excecao;

import java.sql.SQLException;

public class Excecao extends Exception {
	public static String tratarErro(Exception e){
		if (e instanceof SQLException){
			return "Login negado";
		}else if(e instanceof NumberFormatException){
			return "N�mero inv�lido";
		}else{
			return "Erro desconhecido";
		}
	}
}
