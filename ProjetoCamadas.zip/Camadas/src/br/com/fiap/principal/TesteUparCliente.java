package br.com.fiap.principal;

import javax.swing.JOptionPane;

import br.com.fiap.dao.ClienteDAO;

public class TesteUparCliente {

	public static void main(String[] args) {
		ClienteDAO dao = null;
		try{
			dao = new ClienteDAO();
			System.out.println
				(dao.uparNivel
				(Integer.parseInt
				(JOptionPane.showInputDialog
				("Digite o n�mero"))));
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				dao.fechar();
			}catch (Exception e){
				e.printStackTrace();
			}
		}

	}

}
