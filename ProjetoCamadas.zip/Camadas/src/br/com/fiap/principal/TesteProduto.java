package br.com.fiap.principal;

import javax.swing.JOptionPane;

import br.com.fiap.dao.ProdutoDAO;

public class TesteProduto {

	public static void main(String[] args) {
		ProdutoDAO dao=null;
		try{
			do{
				char opc=JOptionPane.showInputDialog
						("Escolha uma das op��es:\n"
								+ "<C> - Cadastrar\n"
								+ "<O> - Consultar por Codigo\n"
								+ "<V> - Consultar por Valor").toUpperCase().charAt(0);
				if (opc=='C'){
					//codigo para executar o gravar
				}else if(opc=='O'){
					//codigo para executar o consultarPorCodigo
				}else if(opc=='V'){
					//codigo para executar o consultarPorValor
				}else if(opc=='L'){
					//codigo para executar o listarPorValor
				}else{
					System.out.println("Op��o inv�lida");
				}
			}while(JOptionPane.showConfirmDialog
					(null, "Continuar?","ProdutoDAO",
					JOptionPane.YES_NO_OPTION, 
					JOptionPane.QUESTION_MESSAGE)==0);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				dao.fechar();
			}catch(Exception e){
				e.printStackTrace();
			}
		}

	}

}
