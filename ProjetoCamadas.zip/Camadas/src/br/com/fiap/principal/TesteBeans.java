package br.com.fiap.principal;

import br.com.fiap.beans.Cliente;

public class TesteBeans {
	public static void main(String[] args) {
		Cliente obj = new Cliente("joao", 1, 1);
		System.out.println(obj.getNome());
	}
}
