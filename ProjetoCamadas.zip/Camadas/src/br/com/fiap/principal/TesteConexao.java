package br.com.fiap.principal;

import java.sql.Connection;

import br.com.fiap.conexao.ConexaoFactory;

public class TesteConexao {

	public static void main(String[] args) {
		ConexaoFactory cf = new ConexaoFactory();
		Connection c = null;
		try{
			c = cf.connect();
			System.out.println("Parab�ns Juninho");
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}





