package br.com.fiap.beans;

public class Cliente {
	private String nome;
	private int numero;
	private int qtdeEstrela;
	
	public Cliente(String nome, int numero, int qtdeEstrela) {
		super();
		setNome(nome);
		setNumero(numero);
		setQtdeEstrela(qtdeEstrela);
	}
	public Cliente() {
		super();
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome.toUpperCase();
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public int getQtdeEstrela() {
		return qtdeEstrela;
	}
	public void setQtdeEstrela(int qtdeEstrela) {
		this.qtdeEstrela = qtdeEstrela;
	}

	}


