package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.fiap.beans.Cliente;
import br.com.fiap.beans.Produto;
import br.com.fiap.conexao.ConexaoFactory;

public class ProdutoDAO {
	private Connection con;
	public ProdutoDAO()throws Exception{
		con = new ConexaoFactory().connect();
	}
    public String fechar() throws Exception{
    	con.close();
    	return "Gravado com sucesso!";
    }
    // INSERT INTO PRODUTOS(NOME,PRECO) VALUES ('PRD',15.60)
    public String gravar(Produto prod) throws Exception{
    	
    	PreparedStatement estrutura= 
    	con.prepareStatement("INSERT INTO TAB_POO_PRODUTO (CD_PRODUTO, DS_PRODUTO, NM_CATEGORIA, VL_PRODUTO) VALUES(?,?,?,?)");
    	estrutura.setInt(1, prod.getCodigo());
    	estrutura.setString(2, prod.getDescricao());
    	estrutura.setString(3, prod.getCategoria());
    	estrutura.setDouble(4, prod.getValor());
    	
    	int churros = estrutura.executeUpdate();
    	estrutura.close();
    	return churros + " cliente(s) foi(ram) adicionar";
    }    
    public Cliente getCliente(int pNumero)throws Exception{
    	PreparedStatement estrutura =  con.prepareStatement("select * from TAB_POO_CLIENTE WHERE NR_CLIENTE = ?");
    	estrutura.setInt(1, pNumero);
    	ResultSet resultado = estrutura.executeQuery();
    	Cliente obj = new Cliente();
    	if(resultado.next()){
    		
    		obj.setNome(resultado.getString("NM_CLIENTE"));
    		obj.setNumero(resultado.getInt("NR_CLIENTE"));
    		obj.setQtdeEstrela(resultado.getInt("QT_ESTRELAS"));
    		
    	}
    	
    	estrutura.close();
    	return obj;
     }
    public String uparNivel(int pNumero)throws Exception{
    	PreparedStatement estrutura = con.prepareStatement
    			("UPDATE TAB_POO_CLIENTE SET QT_ESTRELAS = QT_ESTRELAS+1 WHERE NR.CLIENTE = ?");
    	estrutura.setInt(1, pNumero);
    	int x = estrutura.executeUpdate();
    	return x + "cliente(s) foi(ram) updados(s)!";
    }
    public int excluir (int pNumero)throws Exception{
    	PreparedStatement estrutura = con.prepareStatement
    			("DELETE FROM TAB_POO_CLIENTE WHERE NR.CLIENTE = ?");
    	estrutura.setInt(1, pNumero);
    	int x = estrutura.executeUpdate();
    	estrutura.close();
    	return x;
    }	
    
}
