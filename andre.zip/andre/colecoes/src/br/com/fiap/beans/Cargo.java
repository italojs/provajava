package br.com.fiap.beans;

public class Cargo {
	private String cargo;
	private String nivel;
	private double salario;
	
	public Cargo(){
		
	}
	public Cargo(String cargo,String nivel,double salario){
		this.cargo = cargo;
		this.nivel = nivel;
		this.salario = salario;
	}
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	public String getNivel() {
		return nivel;
	}
	public void setNivel(String nivel) {
		this.nivel = nivel;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	
	
}
