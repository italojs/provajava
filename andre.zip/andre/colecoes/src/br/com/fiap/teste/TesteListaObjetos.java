package br.com.fiap.teste;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import br.com.fiap.beans.Cargo;

public class TesteListaObjetos {
	public static void main(String[] args) {
		//Interface (List) e depois implementa��o (Arraylist)
		List<Cargo> cargos = new ArrayList<Cargo>();
		
		Cargo c1 = new Cargo("Dev","Senior",20000);	
		Cargo c2 = new Cargo("DBA","Junior",3000);  
		Cargo c3 = new Cargo("DEVOPS","Pleno",15000);  
		
		cargos.add(c1);
		cargos.add(c2);
		cargos.add(c3);
		
		System.out.print(cargos);
	}
}
