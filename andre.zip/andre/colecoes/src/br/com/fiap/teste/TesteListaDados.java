package br.com.fiap.teste;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TesteListaDados {

	public static void main(String[] args) {
		//Interface (List) e depois implementa��o (Arraylist)
		List<String> cargos = new ArrayList<String>();
		
		//NUNCA UTILIZAR DESTA MANEIRA
        //ArrayList<String> xpto = new ArrayList<String>();
		
		cargos.add("DBA");
		cargos.add("Estagiario");
		cargos.add("Dev Jr.");
		System.out.println(cargos);
		Collections.sort(cargos);
		System.out.println(cargos);	
		
		Set<String> cargos2 = new HashSet<String>();
		cargos.add("DBA");
		cargos.add("DBA");
		cargos.add("Estagiario");
		//Nao da pra 'sortar' um Set
		//Collections.sort(cargos2);
		cargos.add("Dev Jr.");
		System.out.println(cargos2);
		
		
		
	}

}
