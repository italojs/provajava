/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fiap.dao;

import br.com.fiap.beans.Cliente;
import br.com.fiap.conexao.ConexaoFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author logonrm
 */
public class ClienteDAO {
    private Connection con;
    
    public ClienteDAO()throws Exception{
       con = new ConexaoFactory().connect();       
    }
    
    public String fechar()throws Exception{
        con.close();
        return "Parabens juninho!";
    }
    
    public String gravar(Cliente cli)throws Exception{
        PreparedStatement estrutura = con.prepareStatement
            ("INSERT INTO TB_POO_CLIENTE"
            +"(NM_CLIENTE, NR_CLIENTE,QT_ESTRELAS) VALUES (?,?,?)");
        estrutura.setString(1,cli.getNome());
        estrutura.setInt(2,cli.getNumero());
        estrutura.setInt(3,cli.getQtdEstrelas());
        
        int churros = estrutura.executeUpdate();
        estrutura.close();              
        return churros+" gravado com sucesso";
    }
    
}
