/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fiap.principal;

import br.com.fiap.conexao.ConexaoFactory;
import java.sql.Connection;

/**
 *
 * @author logonrm
 */
public class TesteConexao {
    public static void main(String[] args){
        ConexaoFactory cf = new  ConexaoFactory();
        Connection c = null;
        try{
            c = cf.connect();
            System.out.println("Parabéns juninho");
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
