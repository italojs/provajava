/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fiap.principal;

import br.com.fiap.beans.Cliente;
import br.com.fiap.dao.ClienteDAO;
import javax.swing.JOptionPane;

/**
 *
 * @author logonrm
 */
public class TesteGravarCliente {
    public static void main(String[] args) {
        ClienteDAO dao = null;
        try{            
            dao = new ClienteDAO();
            Cliente cli = new Cliente();
            cli.setNome(JOptionPane.showInputDialog("Nome: "));
            cli.setNumero(Integer.parseInt(JOptionPane.showInputDialog("Numero: ")));
            cli.setQtdEstrelas(Integer.parseInt(JOptionPane.showInputDialog("QTD. de estrelas: ")));
            dao.gravar(cli);            
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            try {
                dao.fechar();
            } catch (Exception e) {
                e.printStackTrace();
            }            
        }        
    }    
}
