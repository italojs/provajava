package APP;

public class Normal extends Empregado {   
    public Normal() {        
    }   
    public Normal(Normal func) { super(func); } 
    public double salario() {
        return this.getDias() * Empresa.getSalDia(); 
    }
    public String toString() {
        return super.toString() + 
               "Sal�rio: R$ "+ this.salario() + " \n"; 
    } 
    public Normal clone() { return new Normal(this); }
    
}
