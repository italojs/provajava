package APP;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.JOptionPane;

public class Control  {
	
	private HashSet<Empregado> empregados = new HashSet<Empregado>();
	
	public void cadastrar(int x){		
		for(int i=0;i<x;i++){
			boolean foi = false;
			while(!foi){
				String op = JOptionPane.showInputDialog("Qual tipo de empregado deseja cadastrar? \n"+
						  "1-Gestor \n"
						+ "2-Comercial \n"
						+ "3-Motorista \n"
						+ "4-Normal \n"
						+ "0-Voltar");
				switch(op){
					case "0":foi=true;break;
					case "1":cadGestor();foi=true;break;
					case "2":cadComerc();foi=true;break;
					case "3":cadMotor();foi=true;break;
					case "4":cadNormal();foi=true;break;
					default:JOptionPane.showMessageDialog(null,"Opcao Invalida!");
				}
			}
		}		
	}
	
	private void cadGestor(){	
		Gestor gest = new Gestor();
		gest.cadastrar();
		empregados.add(gest);
		JOptionPane.showMessageDialog(null,"Gestor Cadastrado com sucesso!");		
		
	}
	private void cadComerc(){				
		Comercial com = new Comercial();
		com.cadastrar();
		empregados.add(com);
		JOptionPane.showMessageDialog(null,"Comercial Cadastrado com sucesso!");			
	}
	private void cadMotor(){	
		Motorista mot = new Motorista();
		mot.cadastrar();
		empregados.add(mot);
		JOptionPane.showMessageDialog(null,"Motorista Cadastrado com sucesso!");			
	}
	private void cadNormal(){	
		Normal norm = new Normal();
		norm.cadastrar();
		empregados.add(norm);
		JOptionPane.showMessageDialog(null,"Funcionario Cadastrado com sucesso!");			
	}
	
	public void pesquisar(){
		String cod = JOptionPane.showInputDialog("Pesquisar por c�digo: ");
		Empregado emp = daFichaEmp(cod);
		
		if(emp!=null){
			JOptionPane.showMessageDialog(null, emp.toString());
		}else{
			JOptionPane.showMessageDialog(null, "Funcionario n�o encontrado!");
		}
	}
	
	public boolean existeEmp(String cod) {
	      boolean existe = false;
	      Iterator<Empregado> itEmp = empregados.iterator();
	      while(itEmp.hasNext() && !existe) {
	          if(itEmp.next().getCodigo().equals(cod)) 
	                existe = true;
	      }
	      return existe;
	  }
	
	public Empregado daFichaEmp(String cod) {
	      boolean existe = false; 
	      Empregado emp = null;
	      Iterator<Empregado> itEmp = empregados.iterator();
	      while(itEmp.hasNext() && !existe) {
	          emp = itEmp.next();
	          if(emp.getCodigo().equals(cod)) 
	                existe = true;
	      }
	      return existe ? emp.clone() : null;
	  }
	
	public int totalGestores() {
	      int total = 0;
	      for(Empregado emp : empregados) 
	           if(emp instanceof Gestor) total++;
	      return total;
	 }
		
	  public int totalDe(String tipo) {
		 int total = 0; 
		  for(Empregado emp : empregados)
		    if(emp.getClass().getSimpleName().equals(tipo)) 
		          total++;
		  return total;
	  } 
	  
	  public String toString() {
	      StringBuilder sb = 
	         new StringBuilder("--- Empregados ---\n\n");
	      for(Empregado emp : empregados)
	        sb.append(emp.toString() + "\n");
	      return sb.toString();
	  }
	  
	  public void gravaTxt(String fich)throws IOException {
		PrintWriter pw = new PrintWriter(fich);
		pw.print(this);
		pw.flush(); pw.close();
	 }
	  public double totalKms() {
	      double totalKm = 0.0;
	      for(Empregado emp : empregados) 
	        if(emp instanceof Motorista) 
	             totalKm += ((Motorista) emp).getKms();
	      return totalKm;
	  }
}
