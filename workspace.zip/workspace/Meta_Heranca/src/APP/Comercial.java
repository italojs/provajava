package APP;

import javax.swing.JOptionPane;

public class Comercial extends Empregado {
    private double vendas;
    // construtores
    public Comercial() {
        
    }   
    public Comercial(Comercial com) {
       super(com); vendas = com.getVendas();
    }
    public double getVendas() { return vendas; }
    public void setVendas(double vendas) { this.vendas = vendas; }
    public void somaVendas(double novas) {
        vendas += novas;
    }
    // Implementa��o dos abstratos
    public double salario() {
        return this.getDias() * Empresa.getSalDia() + 
               vendas * Empresa.getComissao();
    }
    public String toString() {
        return super.toString() + " - " + 
               this.salario() + " Reais \n"; 
    } 
    public Comercial clone() { return new Comercial(this); }
    
    public void cadastrar(){
    	super.cadastrar();
    	this.setVendas(Double.parseDouble(JOptionPane.showInputDialog("Vendas:")));
    }
}