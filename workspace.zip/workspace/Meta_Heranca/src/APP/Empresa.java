package APP;

import java.util.*;
import java.io.*;
public class Empresa {
   // de classe
   private static double salDia = 60.00;
   public static double getSalDia() { return salDia; }
   public static void setSalDia(double nvSal) { 
	   salDia = nvSal; 
   }
   private static double valorKm = 0.025;
   public static double getValorKm() { return valorKm; }
   public static void mudaValorKm(double nvValKm) { 
	   valorKm = nvValKm; 
   }
   private static double comissao = 0.15;
   public static double getComissao() { return comissao; }
   public static void mudaComissao(double nvCom) { 
	   comissao = nvCom; 
   }

   // de inst�ncia
  private HashSet<Empregado> emps = 
                new HashSet<Empregado>();
   // construtores
  public Empresa() { }
  
  public Empresa(HashSet<Empregado> lstEmp) {
      for(Empregado emp : lstEmp)
    	  emps.add(emp.clone());
  }
  
  public Empresa(Empresa empresa) {
     HashSet<Empregado> aux = empresa.daListaEmps();
     for(Empregado emp : aux) emps.add(emp);
  }
  
  public boolean existeEmp(String cod) {
      boolean existe = false;
      Iterator<Empregado> itEmp = emps.iterator();
      while(itEmp.hasNext() && !existe) {
          if(itEmp.next().getCodigo().equals(cod)) 
                existe = true;
      }
      return existe;
  }
  
  public Empregado daFichaEmp(String cod) {
      boolean existe = false; 
      Empregado emp = null;
      Iterator<Empregado> itEmp = emps.iterator();
      while(itEmp.hasNext() && !existe) {
          emp = itEmp.next();
          if(emp.getCodigo().equals(cod)) 
                existe = true;
      }
      return existe ? emp.clone() : null;
  }
  
  public void insereEmp(Empregado emp) {
	  emps.add(emp.clone());
  }
  
  public void juntaEmpregados(HashSet<Empregado> lstEmp) {
	  for(Empregado emp : lstEmp) emps.add(emp.clone());
  }
  
  public HashSet<Empregado> daListaEmps() {
     HashSet<Empregado> aux = new HashSet<Empregado>();
     for(Empregado emp : emps) aux.add(emp.clone());
     return aux;
  }
  
  public double totalSalarios() {
      double total = 0.0;
      for(Empregado emp : emps) 
               total += emp.salario();
      return total;
  }  
  
  public double totalKms() {
      double totalKm = 0.0;
      for(Empregado emp : emps) 
        if(emp instanceof Motorista) 
             totalKm += ((Motorista) emp).getKms();
      return totalKm;
  }  
  
  
  
  
}
	
	
	


