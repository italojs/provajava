package APP;

public class Principal {
    
    public static void main(String[] args) {
        
//        Empresa empresa1 = new Empresa();
//        // cria��o e inser��o das fichas de empregados
//        Empregado emp1 = new Normal("E12", "Rui", 20);
//        empresa1.insereEmp(emp1);
//        emp1 = new Normal("E9", "Ana", 19);
//        empresa1.insereEmp(emp1);
//        emp1 = new Motorista("E29", "Luis", 20, 350);
//        empresa1.insereEmp(emp1);
//        emp1 = new Motorista("E39", "Manuel", 20, 150);
//        empresa1.insereEmp(emp1);
//        emp1 = new Gestor("E3", "Carlos", 20, 0.15);
//        empresa1.insereEmp(emp1);
//        emp1 = new Gestor("E7", "Marta", 20, 0.20);
//        empresa1.insereEmp(emp1);
//        emp1 = new Comercial("E10", "Lemos", 20, 1900);
//        empresa1.insereEmp(emp1);
//        emp1 = new Comercial("E5", "Jaime", 20, 1200);
//        empresa1.insereEmp(emp1);
//        // opera��es a testar 
//        System.out.println(empresa1.toString());
//        System.out.println("Total de Gestores = " +
//                            empresa1.totalGestores());
    	View view = new View();
    }
    
}
