package APP;

import javax.swing.JOptionPane;

public class Gestor extends Empregado {
    private double premio;     
    
    Gestor(){
    
    }
    public Gestor(Gestor gest) {
        super(gest); 
        premio = gest.getPremio();
    }
    
    public double getPremio() { return premio; }
    public void setPremio(double prem) { this.premio = prem; }  
    
    // Implementa��o dos abstratos
    public double salario() {
             return this.getDias() * Empresa.getSalDia() 
                    * (1.0 + premio);
    }
    public String toString() {
        return super.toString() + 
               "Salario: R$ "+this.salario() + " \n"; 
    } 
    public Gestor clone() { return new Gestor(this); }
    
    public void cadastrar(){
    	super.cadastrar();
    	this.setPremio(Double.parseDouble(JOptionPane.showInputDialog("Premio:")));
    }
    
}
