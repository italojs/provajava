package APP;

import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.EventHandler;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class View extends JFrame{
		
	//DECLARANDO OS ELEMENTOS DA TELA
	JPanel painel_principal= new JPanel();
	JButton botaoGestores = new JButton("Contar Gestores");
	JButton botaoInsert = new JButton("Cadastrar");
	JButton botaoSearch = new JButton("Pesquisar");
	JButton botaoInsertList = new JButton("Cadastrar Lista");
	JButton botaoCategoria = new JButton("Contar Categoria");
	JButton botaoTodos = new JButton("Listar Fichas");
	JButton botaoSalvar = new JButton("Salvar");
	JLabel txtTitulo = new JLabel("Op��es");
	
	View(){
		super("Empregados");
		//CONFIGURANDO ELEMENTOS
		txtTitulo.setBounds(20, 20, 200, 40 );
		txtTitulo.setFont(new Font("serif",Font.PLAIN,18));
		
		botaoGestores.setBounds(20, 130, 150, 30);		
		botaoInsert.setBounds(20, 80, 150, 30);
		botaoSearch.setBounds(190, 80, 150, 30);
		botaoInsertList.setBounds(360, 80, 150, 30);
		botaoCategoria.setBounds(190, 130, 150, 30);
		botaoTodos.setBounds(360, 130, 150, 30);
		botaoSalvar.setBounds(360, 260, 150, 30);
		
		Container cont = this.getContentPane();
		setLayout(null);
		
		//ADICIONANDO ITENS NO PAINEL
		cont.add(txtTitulo);
		cont.add(botaoGestores);			
		cont.add(botaoInsert);			
		cont.add(botaoSearch);			
		cont.add(botaoInsertList);
		cont.add(botaoCategoria);
		cont.add(botaoSalvar);
		cont.add(botaoTodos);
		
		//CONFIGURANDO E EXIBINDO JANELA
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setBounds(400,200,550,350);
		this.setVisible(true);
		
		Control control = new Control();		
		
		botaoInsert.addActionListener(new ActionListener(){			
			@Override
			public void actionPerformed(ActionEvent e) {
				control.cadastrar(1);				
			}
		});	
		botaoSearch.addActionListener(new ActionListener(){			
			@Override
			public void actionPerformed(ActionEvent e) {
				control.pesquisar();				
			}
		});	
		
		botaoInsertList.addActionListener(new ActionListener(){			
			@Override
			public void actionPerformed(ActionEvent e) {
				int op = Integer.parseInt(JOptionPane.showInputDialog("Quantos Funcion�rios quer cadastrar?"));
				control.cadastrar(op);				
			}
		});	
		
		botaoGestores.addActionListener(new ActionListener(){			
			@Override
			public void actionPerformed(ActionEvent e) {				
				JOptionPane.showMessageDialog(null,"Total de Gestores: "+control.totalGestores());				
			}
		});
		
		botaoCategoria.addActionListener(new ActionListener(){			
			@Override
			public void actionPerformed(ActionEvent e) {
				String op = JOptionPane.showInputDialog("Qual categoria deseja contar?");
				JOptionPane.showMessageDialog(null,"Total de funcion�rios na categoria "+op+": "+control.totalDe(op));				
			}
		});
		botaoTodos.addActionListener(new ActionListener(){			
			@Override
			public void actionPerformed(ActionEvent e) {				
				JOptionPane.showMessageDialog(null,control.toString());				
			}
		});	
		botaoSalvar.addActionListener(new ActionListener(){			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					control.gravaTxt("d:\\oi.txt");
					JOptionPane.showMessageDialog(null,"Arquivo gerado com sucesso!");	
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null,"Erro ao gerar arquivo!");
				}
							
			}
		});	
	}
}
