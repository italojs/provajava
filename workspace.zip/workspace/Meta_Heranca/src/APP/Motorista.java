package APP;

import javax.swing.JOptionPane;

public class Motorista extends Empregado {

	   // de inst�ncia
	   private double kiloms; 

	   // construtores
	   public Motorista() {	       
	   }   
	   public Motorista(Motorista motorista) {
	       super(motorista); 
	       kiloms = motorista.getKms();
	   }
	   
	   public double getKms() { return kiloms; }
	   public void setKms(double kms) { this.kiloms= kms; }	 
	   //implementa��o dos abstratos
	   public double salario() { 
	       return this.getDias() * Empresa.getSalDia() + 
	              (kiloms * Empresa.getValorKm()); }
	   
	   public String toString() {
	        return super.toString() + 
	              "Salario :R$ "+ this.salario() + " \n"; 
	   } 

	   public Motorista clone() { return new Motorista(this); }
	   public void cadastrar(){
	    	super.cadastrar();
	    	this.setKms(Double.parseDouble(JOptionPane.showInputDialog("Kms:")));
	    }
	}