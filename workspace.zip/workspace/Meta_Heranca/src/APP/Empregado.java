package APP;

import javax.swing.JOptionPane;

public abstract class Empregado {
   // de inst�ncia
   private String codigo;
   private String nome;
   private int dias;
   
// construtores
   public Empregado() {
       
   }   
   public Empregado(Empregado emp) {
       codigo = emp.getCodigo(); nome = emp.getNome(); 
       dias = emp.getDias();
   }
   public String getNome() { return nome; }
   public void setNome(String nm) { nome = nm; }
   
   public String getCodigo() { return codigo; }
   public void setCodigo(String cod) { this.codigo =cod;}
   
   public int getDias() { return dias; }
   public void setDias(int days) { dias = days; }

   public String toString() {
        return "Codigo: "+this.getCodigo()+"\n"+
        	   "Nome: "+this.getNome() + "\n"+
        	   "Cargo: "+this.getClass().getSimpleName()+ "\n";
   } 
   
   // m�todos abstratos
   public abstract double salario();
   public abstract Empregado clone();
   
   public void cadastrar(){
	   this.setCodigo(JOptionPane.showInputDialog("Cod:"));
	   this.setNome(JOptionPane.showInputDialog("Nome:"));
	   this.setDias(Integer.parseInt(JOptionPane.showInputDialog("Dias:")));
   }
}
